This is a menu program!

Build Procedure
      $ gcc linktable.c menu.c -o menu
      $ ./menu # you can input help/version/quit cmd.
